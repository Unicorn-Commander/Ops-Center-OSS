/**
 * Service descriptions and metadata
 */

export const serviceDescriptions = {
  'unicorn-vllm': {
    name: 'vLLM Engine',
    description: 'High-performance LLM inference server',
    category: 'AI/ML',
    icon: 'cpu',
    color: 'blue',
    docs: 'https://github.com/vllm-project/vllm'
  },
  'unicorn-open-webui': {
    name: 'Open WebUI',
    description: 'Web interface for AI chat',
    category: 'UI',
    icon: 'chat',
    color: 'green',
    docs: 'https://github.com/open-webui/open-webui'
  },
  'unicorn-center-deep': {
    name: 'Center Deep',
    description: 'AI-powered metasearch engine',
    category: 'Search',
    icon: 'search',
    color: 'purple',
    docs: 'https://github.com/Unicorn-Commander/Center-Deep-Pro'
  },
  'unicorn-embeddings': {
    name: 'Embeddings',
    description: 'Text embedding service',
    category: 'AI/ML',
    icon: 'vector',
    color: 'orange',
    docs: ''
  },
  'unicorn-reranker': {
    name: 'Reranker',
    description: 'Document reranking service',
    category: 'AI/ML',
    icon: 'sort',
    color: 'yellow',
    docs: ''
  },
  'unicorn-postgresql': {
    name: 'PostgreSQL',
    description: 'Relational database',
    category: 'Database',
    icon: 'database',
    color: 'indigo',
    docs: 'https://www.postgresql.org/'
  },
  'unicorn-redis': {
    name: 'Redis',
    description: 'In-memory data store',
    category: 'Cache',
    icon: 'lightning',
    color: 'red',
    docs: 'https://redis.io/'
  },
  'unicorn-qdrant': {
    name: 'Qdrant',
    description: 'Vector database',
    category: 'Database',
    icon: 'cube',
    color: 'teal',
    docs: 'https://qdrant.tech/'
  },
  'authentik-server': {
    name: 'Authentik',
    description: 'Identity provider and SSO',
    category: 'Security',
    icon: 'shield',
    color: 'cyan',
    docs: 'https://goauthentik.io/'
  },
  'traefik': {
    name: 'Traefik',
    description: 'Reverse proxy and load balancer',
    category: 'Network',
    icon: 'globe',
    color: 'lime',
    docs: 'https://traefik.io/'
  }
};

export function getServiceInfo(serviceName) {
  return getServiceDescription(serviceName);
}

export function getGPUUsageSummary() {
  // Mock GPU usage summary
  return {
    totalMemory: 32768, // 32GB in MB
    usedMemory: 16384,  // 16GB used
    utilization: 50,    // 50% utilization
    temperature: 65     // 65°C
  };
}

export function getServiceDescription(serviceName) {
  // Try exact match first
  if (serviceDescriptions[serviceName]) {
    return serviceDescriptions[serviceName];
  }

  // Try partial match
  for (const key in serviceDescriptions) {
    if (serviceName.includes(key) || key.includes(serviceName)) {
      return serviceDescriptions[key];
    }
  }

  // Return default
  return {
    name: serviceName,
    description: 'Docker container service',
    category: 'Other',
    icon: 'box',
    color: 'gray',
    docs: ''
  };
}