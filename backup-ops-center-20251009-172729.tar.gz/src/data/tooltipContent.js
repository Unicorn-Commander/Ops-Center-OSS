/**
 * Tooltip content for UI components
 */

const tooltips = {
  storage: {
    backup: "Create a backup of your data",
    restore: "Restore from a previous backup",
    schedule: "Schedule automatic backups",
    retention: "How long to keep backup files"
  },
  models: {
    download: "Download model from repository",
    delete: "Remove model from local storage",
    activate: "Load model into memory",
    settings: "Configure model parameters"
  },
  services: {
    start: "Start the service",
    stop: "Stop the service",
    restart: "Restart the service",
    logs: "View service logs"
  }
};

export function getTooltip(category, key) {
  if (!tooltips[category] || !tooltips[category][key]) {
    return "";
  }
  return tooltips[category][key];
}

export const tooltipPresets = {
  services: {
    start: "Click to start this service",
    stop: "Click to stop this service",
    restart: "Click to restart this service",
    logs: "View logs for this service",
    delete: "Remove this service"
  }
};

export default tooltips;