/**
 * Service information and tips for model management
 */

export const serviceInfo = {
  vllm: {
    name: "vLLM",
    description: "High-performance LLM inference engine",
    tips: [
      "Optimized for NVIDIA GPUs",
      "Supports quantization for memory efficiency",
      "OpenAI-compatible API"
    ]
  },
  ollama: {
    name: "Ollama",
    description: "Local LLM runner with easy model management",
    tips: [
      "Simple model installation",
      "Supports various model formats",
      "Built-in model library"
    ]
  },
  embeddings: {
    name: "Embeddings",
    description: "Text embedding service for vector operations",
    tips: [
      "Convert text to vectors",
      "Used for semantic search",
      "Powers RAG applications"
    ]
  },
  reranker: {
    name: "Reranker",
    description: "Document reranking for improved search results",
    tips: [
      "Improves search relevance",
      "Works with embedding models",
      "Optimizes retrieval quality"
    ]
  }
};

export const modelTips = {
  quantization: {
    AWQ: "Activation-aware Weight Quantization - Best speed/quality balance",
    GPTQ: "GPT Quantization - Good for older hardware",
    GGUF: "GPT-Generated Unified Format - Ollama format",
    FP16: "16-bit floating point - Good quality, moderate size",
    INT8: "8-bit integer - Smaller size, some quality loss"
  },
  context: {
    small: "2K-4K tokens - Good for chat",
    medium: "8K-16K tokens - Document processing",
    large: "32K+ tokens - Long documents"
  }
};