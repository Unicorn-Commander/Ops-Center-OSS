import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  CreditCardIcon,
  BanknotesIcon,
  UsersIcon,
  ChartBarIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  CheckCircleIcon,
  XCircleIcon,
  ClockIcon,
  DocumentArrowDownIcon,
  PlusCircleIcon,
  TrashIcon,
  MagnifyingGlassIcon,
  ExclamationTriangleIcon,
  SparklesIcon,
  ArrowPathIcon
} from '@heroicons/react/24/outline';
import { useTheme } from '../contexts/ThemeContext';
import {
  PieChart,
  Pie,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell
} from 'recharts';

// Animation variants
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { duration: 0.3 }
  }
};

// Format currency
const formatCurrency = (amount) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(amount);
};

// Format date
const formatDate = (dateString) => {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
};

// Tier badge component
const TierBadge = ({ tier }) => {
  const colors = {
    trial: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    starter: 'bg-green-500/20 text-green-400 border-green-500/30',
    professional: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    enterprise: 'bg-amber-500/20 text-amber-400 border-amber-500/30'
  };

  return (
    <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${colors[tier] || colors.trial}`}>
      {tier.charAt(0).toUpperCase() + tier.slice(1)}
    </span>
  );
};

// Status badge component
const StatusBadge = ({ status }) => {
  const colors = {
    active: 'bg-green-500/20 text-green-400 border-green-500/30',
    trialing: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    canceled: 'bg-red-500/20 text-red-400 border-red-500/30',
    past_due: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    paid: 'bg-green-500/20 text-green-400 border-green-500/30',
    pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    failed: 'bg-red-500/20 text-red-400 border-red-500/30'
  };

  return (
    <span className={`px-2 py-1 rounded-full text-xs font-medium border ${colors[status] || colors.pending}`}>
      {status.charAt(0).toUpperCase() + status.slice(1).replace('_', ' ')}
    </span>
  );
};

// Loading skeleton
const LoadingSkeleton = ({ theme }) => (
  <div className="space-y-6">
    {[1, 2, 3].map((i) => (
      <div key={i} className={`${theme.card} rounded-xl p-6 animate-pulse`}>
        <div className="h-4 bg-slate-700 rounded w-1/4 mb-4"></div>
        <div className="h-8 bg-slate-700 rounded w-1/2"></div>
      </div>
    ))}
  </div>
);

// Empty state component
const EmptyState = ({ icon: Icon, title, description, action, theme }) => (
  <div className={`${theme.card} rounded-xl p-12 text-center`}>
    <Icon className="w-16 h-16 mx-auto mb-4 text-slate-500" />
    <h3 className={`text-xl font-semibold mb-2 ${theme.text.primary}`}>{title}</h3>
    <p className={`${theme.text.secondary} mb-6`}>{description}</p>
    {action && action}
  </div>
);

// User View Component
const UserView = ({ theme }) => {
  const [loading, setLoading] = useState(true);
  const [subscription, setSubscription] = useState(null);
  const [invoices, setInvoices] = useState([]);
  const [paymentMethods, setPaymentMethods] = useState([]);
  const [usage, setUsage] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadUserBillingData();
  }, []);

  const loadUserBillingData = async () => {
    setLoading(true);
    try {
      const [subRes, invRes, pmRes, usageRes] = await Promise.all([
        fetch('/api/v1/billing/subscription'),
        fetch('/api/v1/billing/invoices?limit=10'),
        fetch('/api/v1/billing/payment-methods'),
        fetch('/api/v1/billing/usage')
      ]);

      if (subRes.ok) setSubscription(await subRes.json());
      if (invRes.ok) setInvoices(await invRes.json());
      if (pmRes.ok) setPaymentMethods(await pmRes.json());
      if (usageRes.ok) setUsage(await usageRes.json());
    } catch (error) {
      console.error('Error loading billing data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadUserBillingData();
    setRefreshing(false);
  };

  if (loading) {
    return <LoadingSkeleton theme={theme} />;
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      {/* Header with Refresh */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className={`text-2xl font-bold ${theme.text.primary}`}>Billing & Subscription</h2>
          <p className={`${theme.text.secondary} text-sm mt-1`}>Manage your subscription and billing information</p>
        </div>
        <button
          onClick={handleRefresh}
          disabled={refreshing}
          className={`flex items-center gap-2 px-4 py-2 ${theme.button} rounded-lg transition-all disabled:opacity-50`}
        >
          <ArrowPathIcon className={`w-5 h-5 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {/* Current Subscription */}
      <motion.div variants={itemVariants} className={`${theme.card} rounded-xl p-6`}>
        <div className="flex items-center justify-between mb-4">
          <h3 className={`text-lg font-semibold ${theme.text.primary} flex items-center gap-2`}>
            <SparklesIcon className="w-5 h-5 text-purple-400" />
            Current Subscription
          </h3>
          {subscription && <TierBadge tier={subscription.tier} />}
        </div>

        {subscription ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className={`text-sm ${theme.text.secondary}`}>Plan</p>
                <p className={`text-xl font-bold ${theme.text.primary}`}>
                  {subscription.tier.charAt(0).toUpperCase() + subscription.tier.slice(1)}
                </p>
              </div>
              <div>
                <p className={`text-sm ${theme.text.secondary}`}>Price</p>
                <p className={`text-xl font-bold ${theme.text.primary}`}>
                  {formatCurrency(subscription.price)}/mo
                </p>
              </div>
              <div>
                <p className={`text-sm ${theme.text.secondary}`}>Status</p>
                <div className="mt-1">
                  <StatusBadge status={subscription.status} />
                </div>
              </div>
              <div>
                <p className={`text-sm ${theme.text.secondary}`}>Next Billing Date</p>
                <p className={`text-sm font-medium ${theme.text.primary} mt-1`}>
                  {formatDate(subscription.next_billing_date)}
                </p>
              </div>
            </div>

            <div className="flex gap-3 pt-4 border-t border-slate-700">
              <button className={`flex-1 ${theme.button} rounded-lg py-2 px-4 text-sm font-medium`}>
                <ArrowUpIcon className="w-4 h-4 inline mr-2" />
                Upgrade Plan
              </button>
              <button className="flex-1 border border-slate-600 text-slate-300 hover:bg-slate-700 rounded-lg py-2 px-4 text-sm font-medium transition-colors">
                Change Plan
              </button>
            </div>
          </div>
        ) : (
          <EmptyState
            icon={CreditCardIcon}
            title="No Active Subscription"
            description="Start your subscription to access premium features"
            action={
              <button className={`${theme.button} rounded-lg py-2 px-6 text-sm font-medium`}>
                View Plans
              </button>
            }
            theme={theme}
          />
        )}
      </motion.div>

      {/* Usage Statistics */}
      {usage && (
        <motion.div variants={itemVariants} className={`${theme.card} rounded-xl p-6`}>
          <h3 className={`text-lg font-semibold ${theme.text.primary} mb-4 flex items-center gap-2`}>
            <ChartBarIcon className="w-5 h-5 text-cyan-400" />
            Usage Statistics
          </h3>

          <div className="space-y-4">
            {/* API Calls */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className={`text-sm ${theme.text.secondary}`}>API Calls</span>
                <span className={`text-sm font-medium ${theme.text.primary}`}>
                  {usage.api_calls_used.toLocaleString()} / {usage.api_calls_limit === -1 ? '∞' : usage.api_calls_limit.toLocaleString()}
                </span>
              </div>
              <div className="w-full bg-slate-700 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all"
                  style={{
                    width: `${usage.api_calls_limit === -1 ? 0 : Math.min((usage.api_calls_used / usage.api_calls_limit) * 100, 100)}%`
                  }}
                />
              </div>
              <p className={`text-xs ${theme.text.secondary} mt-1`}>
                {usage.api_calls_limit === -1 ? 'Unlimited' : `${Math.round((usage.api_calls_used / usage.api_calls_limit) * 100)}% used`}
              </p>
            </div>

            {/* Credits */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className={`text-sm ${theme.text.secondary}`}>Credits</span>
                <span className={`text-sm font-medium ${theme.text.primary}`}>
                  {usage.credits_remaining.toLocaleString()} remaining
                </span>
              </div>
              <div className="w-full bg-slate-700 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-green-500 to-emerald-500 h-2 rounded-full transition-all"
                  style={{
                    width: `${Math.min((usage.credits_remaining / (usage.credits_used + usage.credits_remaining)) * 100, 100)}%`
                  }}
                />
              </div>
              <p className={`text-xs ${theme.text.secondary} mt-1`}>
                {usage.credits_used.toLocaleString()} credits used this month
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {/* Invoice History */}
      <motion.div variants={itemVariants} className={`${theme.card} rounded-xl p-6`}>
        <h3 className={`text-lg font-semibold ${theme.text.primary} mb-4 flex items-center gap-2`}>
          <DocumentArrowDownIcon className="w-5 h-5 text-blue-400" />
          Invoice History
        </h3>

        {invoices.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className={`text-left py-3 px-4 text-sm font-medium ${theme.text.secondary}`}>Date</th>
                  <th className={`text-left py-3 px-4 text-sm font-medium ${theme.text.secondary}`}>Amount</th>
                  <th className={`text-left py-3 px-4 text-sm font-medium ${theme.text.secondary}`}>Status</th>
                  <th className={`text-right py-3 px-4 text-sm font-medium ${theme.text.secondary}`}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {invoices.map((invoice) => (
                  <tr key={invoice.id} className="border-b border-slate-800 hover:bg-slate-700/30 transition-colors">
                    <td className={`py-3 px-4 text-sm ${theme.text.primary}`}>
                      {formatDate(invoice.date)}
                    </td>
                    <td className={`py-3 px-4 text-sm font-medium ${theme.text.primary}`}>
                      {formatCurrency(invoice.amount)}
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={invoice.status} />
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button className="text-purple-400 hover:text-purple-300 text-sm font-medium transition-colors">
                        <DocumentArrowDownIcon className="w-4 h-4 inline mr-1" />
                        Download PDF
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={DocumentArrowDownIcon}
            title="No Invoices Yet"
            description="Your invoice history will appear here once you have active charges"
            theme={theme}
          />
        )}
      </motion.div>

      {/* Payment Methods */}
      <motion.div variants={itemVariants} className={`${theme.card} rounded-xl p-6`}>
        <div className="flex items-center justify-between mb-4">
          <h3 className={`text-lg font-semibold ${theme.text.primary} flex items-center gap-2`}>
            <CreditCardIcon className="w-5 h-5 text-green-400" />
            Payment Methods
          </h3>
          <button className="flex items-center gap-2 text-sm font-medium text-purple-400 hover:text-purple-300 transition-colors">
            <PlusCircleIcon className="w-5 h-5" />
            Add Payment Method
          </button>
        </div>

        {paymentMethods.length > 0 ? (
          <div className="space-y-3">
            {paymentMethods.map((method) => (
              <div
                key={method.id}
                className="flex items-center justify-between p-4 bg-slate-700/30 rounded-lg border border-slate-600 hover:border-slate-500 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <CreditCardIcon className="w-8 h-8 text-slate-400" />
                  <div>
                    <p className={`font-medium ${theme.text.primary}`}>
                      {method.brand} •••• {method.last4}
                    </p>
                    <p className={`text-sm ${theme.text.secondary}`}>
                      Expires {method.exp_month}/{method.exp_year}
                    </p>
                  </div>
                  {method.is_default && (
                    <span className="px-2 py-1 bg-purple-500/20 text-purple-400 text-xs font-medium rounded">
                      Default
                    </span>
                  )}
                </div>
                <button className="text-red-400 hover:text-red-300 transition-colors">
                  <TrashIcon className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={CreditCardIcon}
            title="No Payment Methods"
            description="Add a payment method to manage your subscription"
            action={
              <button className={`${theme.button} rounded-lg py-2 px-6 text-sm font-medium`}>
                <PlusCircleIcon className="w-4 h-4 inline mr-2" />
                Add Card
              </button>
            }
            theme={theme}
          />
        )}
      </motion.div>
    </motion.div>
  );
};

// Admin View Component
const AdminView = ({ theme }) => {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [recentCharges, setRecentCharges] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    setLoading(true);
    try {
      const [statsRes, customersRes, chargesRes] = await Promise.all([
        fetch('/api/v1/admin/billing/stats'),
        fetch('/api/v1/admin/billing/customers?limit=100'),
        fetch('/api/v1/admin/billing/recent-charges?limit=20')
      ]);

      if (statsRes.ok) setStats(await statsRes.json());
      if (customersRes.ok) setCustomers(await customersRes.json());
      if (chargesRes.ok) setRecentCharges(await chargesRes.json());
    } catch (error) {
      console.error('Error loading admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingSkeleton theme={theme} />;
  }

  // Chart colors
  const COLORS = ['#8b5cf6', '#ec4899', '#10b981', '#f59e0b'];

  // Prepare chart data
  const tierData = stats?.subscriptions_by_tier || [];
  const revenueData = stats?.revenue_by_tier || [];

  // Filter customers
  const filteredCustomers = customers.filter((customer) => {
    const matchesSearch =
      customer.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || customer.subscription_status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      {/* Header */}
      <div>
        <h2 className={`text-2xl font-bold ${theme.text.primary}`}>Admin Billing Dashboard</h2>
        <p className={`${theme.text.secondary} text-sm mt-1`}>Monitor revenue, subscriptions, and customer activity</p>
      </div>

      {/* Revenue Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div variants={itemVariants} className={`${theme.card} rounded-xl p-6`}>
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-sm ${theme.text.secondary}`}>Monthly Recurring Revenue</p>
              <p className={`text-3xl font-bold ${theme.text.primary} mt-2`}>
                {formatCurrency(stats?.mrr || 0)}
              </p>
              <div className="flex items-center gap-1 mt-2 text-sm text-green-400">
                <ArrowUpIcon className="w-4 h-4" />
                <span>+{stats?.mrr_growth || 0}% from last month</span>
              </div>
            </div>
            <BanknotesIcon className="w-12 h-12 text-purple-400 opacity-20" />
          </div>
        </motion.div>

        <motion.div variants={itemVariants} className={`${theme.card} rounded-xl p-6`}>
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-sm ${theme.text.secondary}`}>Total Customers</p>
              <p className={`text-3xl font-bold ${theme.text.primary} mt-2`}>
                {stats?.total_customers || 0}
              </p>
              <div className="flex items-center gap-1 mt-2 text-sm text-green-400">
                <ArrowUpIcon className="w-4 h-4" />
                <span>+{stats?.new_customers_this_month || 0} this month</span>
              </div>
            </div>
            <UsersIcon className="w-12 h-12 text-blue-400 opacity-20" />
          </div>
        </motion.div>

        <motion.div variants={itemVariants} className={`${theme.card} rounded-xl p-6`}>
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-sm ${theme.text.secondary}`}>Active Subscriptions</p>
              <p className={`text-3xl font-bold ${theme.text.primary} mt-2`}>
                {stats?.active_subscriptions || 0}
              </p>
              <div className="flex items-center gap-1 mt-2 text-sm text-blue-400">
                <CheckCircleIcon className="w-4 h-4" />
                <span>{stats?.retention_rate || 0}% retention</span>
              </div>
            </div>
            <CheckCircleIcon className="w-12 h-12 text-green-400 opacity-20" />
          </div>
        </motion.div>

        <motion.div variants={itemVariants} className={`${theme.card} rounded-xl p-6`}>
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-sm ${theme.text.secondary}`}>Trial Subscriptions</p>
              <p className={`text-3xl font-bold ${theme.text.primary} mt-2`}>
                {stats?.trial_subscriptions || 0}
              </p>
              <div className="flex items-center gap-1 mt-2 text-sm text-yellow-400">
                <ClockIcon className="w-4 h-4" />
                <span>{stats?.trial_conversion_rate || 0}% convert</span>
              </div>
            </div>
            <ClockIcon className="w-12 h-12 text-yellow-400 opacity-20" />
          </div>
        </motion.div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Subscription Breakdown Pie Chart */}
        <motion.div variants={itemVariants} className={`${theme.card} rounded-xl p-6`}>
          <h3 className={`text-lg font-semibold ${theme.text.primary} mb-4`}>Subscription Breakdown</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={tierData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {tierData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Revenue by Tier Bar Chart */}
        <motion.div variants={itemVariants} className={`${theme.card} rounded-xl p-6`}>
          <h3 className={`text-lg font-semibold ${theme.text.primary} mb-4`}>Revenue by Tier</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1e293b',
                  border: '1px solid #334155',
                  borderRadius: '0.5rem'
                }}
              />
              <Bar dataKey="revenue" fill="#8b5cf6" />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Recent Activity */}
      <motion.div variants={itemVariants} className={`${theme.card} rounded-xl p-6`}>
        <h3 className={`text-lg font-semibold ${theme.text.primary} mb-4`}>Recent Charges</h3>
        {recentCharges.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className={`text-left py-3 px-4 text-sm font-medium ${theme.text.secondary}`}>Customer</th>
                  <th className={`text-left py-3 px-4 text-sm font-medium ${theme.text.secondary}`}>Amount</th>
                  <th className={`text-left py-3 px-4 text-sm font-medium ${theme.text.secondary}`}>Status</th>
                  <th className={`text-left py-3 px-4 text-sm font-medium ${theme.text.secondary}`}>Date</th>
                </tr>
              </thead>
              <tbody>
                {recentCharges.map((charge) => (
                  <tr key={charge.id} className="border-b border-slate-800 hover:bg-slate-700/30 transition-colors">
                    <td className={`py-3 px-4 text-sm ${theme.text.primary}`}>
                      <div>
                        <p className="font-medium">{charge.customer_name}</p>
                        <p className={`text-xs ${theme.text.secondary}`}>{charge.customer_email}</p>
                      </div>
                    </td>
                    <td className={`py-3 px-4 text-sm font-medium ${theme.text.primary}`}>
                      {formatCurrency(charge.amount)}
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={charge.status} />
                    </td>
                    <td className={`py-3 px-4 text-sm ${theme.text.secondary}`}>
                      {formatDate(charge.date)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={BanknotesIcon}
            title="No Recent Charges"
            description="Recent payment activity will appear here"
            theme={theme}
          />
        )}
      </motion.div>

      {/* Customer List */}
      <motion.div variants={itemVariants} className={`${theme.card} rounded-xl p-6`}>
        <h3 className={`text-lg font-semibold ${theme.text.primary} mb-4`}>Customer List</h3>

        {/* Filters */}
        <div className="flex gap-4 mb-4">
          <div className="flex-1 relative">
            <MagnifyingGlassIcon className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search customers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-purple-500"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-purple-500"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="trialing">Trialing</option>
            <option value="canceled">Canceled</option>
            <option value="past_due">Past Due</option>
          </select>
        </div>

        {/* Customer Table */}
        {filteredCustomers.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className={`text-left py-3 px-4 text-sm font-medium ${theme.text.secondary}`}>Customer</th>
                  <th className={`text-left py-3 px-4 text-sm font-medium ${theme.text.secondary}`}>Tier</th>
                  <th className={`text-left py-3 px-4 text-sm font-medium ${theme.text.secondary}`}>Status</th>
                  <th className={`text-left py-3 px-4 text-sm font-medium ${theme.text.secondary}`}>MRR</th>
                  <th className={`text-left py-3 px-4 text-sm font-medium ${theme.text.secondary}`}>Started</th>
                </tr>
              </thead>
              <tbody>
                {filteredCustomers.map((customer) => (
                  <tr key={customer.id} className="border-b border-slate-800 hover:bg-slate-700/30 transition-colors cursor-pointer">
                    <td className={`py-3 px-4 text-sm ${theme.text.primary}`}>
                      <div>
                        <p className="font-medium">{customer.name}</p>
                        <p className={`text-xs ${theme.text.secondary}`}>{customer.email}</p>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <TierBadge tier={customer.subscription_tier} />
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={customer.subscription_status} />
                    </td>
                    <td className={`py-3 px-4 text-sm font-medium ${theme.text.primary}`}>
                      {formatCurrency(customer.mrr)}
                    </td>
                    <td className={`py-3 px-4 text-sm ${theme.text.secondary}`}>
                      {formatDate(customer.subscription_started)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={UsersIcon}
            title="No Customers Found"
            description="No customers match your search criteria"
            theme={theme}
          />
        )}
      </motion.div>
    </motion.div>
  );
};

// Main Component
export default function BillingDashboard() {
  const { theme } = useTheme();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkUserRole();
  }, []);

  const checkUserRole = async () => {
    try {
      const res = await fetch('/api/v1/auth/me');
      if (res.ok) {
        const data = await res.json();
        setIsAdmin(data.is_admin || data.role === 'admin');
      }
    } catch (error) {
      console.error('Error checking user role:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      {isAdmin ? <AdminView theme={theme} /> : <UserView theme={theme} />}
    </div>
  );
}
