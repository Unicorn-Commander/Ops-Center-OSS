import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Avatar,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  FormControlLabel,
  Switch,
  Grid,
  Card,
  CardContent,
  MenuItem,
  Select,
  InputLabel,
  Checkbox,
  List,
  ListItem,
  ListItemText,
  Alert,
  Snackbar,
  CircularProgress,
  Tooltip,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  VpnKey as VpnKeyIcon,
  Security as SecurityIcon,
  ExitToApp as LogoutIcon,
  Search as SearchIcon,
  Refresh as RefreshIcon,
  People as PeopleIcon,
  PersonAdd as PersonAddIcon,
  VerifiedUser as VerifiedUserIcon,
  AdminPanelSettings as AdminIcon,
} from '@mui/icons-material';

const UserManagement = () => {
  // State for user list
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Pagination state
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalUsers, setTotalUsers] = useState(0);

  // Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all'); // all, enabled, disabled

  // Modal states
  const [createEditModalOpen, setCreateEditModalOpen] = useState(false);
  const [roleModalOpen, setRoleModalOpen] = useState(false);
  const [sessionModalOpen, setSessionModalOpen] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [resetPasswordOpen, setResetPasswordOpen] = useState(false);

  // Current user/action data
  const [currentUser, setCurrentUser] = useState(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [userSessions, setUserSessions] = useState([]);
  const [availableRoles, setAvailableRoles] = useState([]);
  const [userRoles, setUserRoles] = useState([]);

  // Statistics
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    verifiedEmails: 0,
    adminUsers: 0,
  });

  // Form data
  const [formData, setFormData] = useState({
    email: '',
    username: '',
    firstName: '',
    lastName: '',
    password: '',
    enabled: true,
    emailVerified: false,
  });

  // Toast notification
  const [toast, setToast] = useState({
    open: false,
    message: '',
    severity: 'success',
  });

  // Fetch users
  const fetchUsers = async () => {
    setLoading(true);
    try {
      const offset = page * rowsPerPage;
      const params = new URLSearchParams({
        first: offset.toString(),
        max: rowsPerPage.toString(),
      });

      if (searchQuery) {
        params.append('search', searchQuery);
      }

      const response = await fetch(`/api/v1/admin/users?${params}`);
      if (!response.ok) throw new Error('Failed to fetch users');

      const data = await response.json();
      setUsers(data.users || []);
      setTotalUsers(data.total || 0);
    } catch (err) {
      setError(err.message);
      showToast('Failed to load users', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Fetch statistics
  const fetchStats = async () => {
    try {
      const response = await fetch('/api/v1/admin/stats');
      if (!response.ok) throw new Error('Failed to fetch stats');

      const data = await response.json();
      setStats(data);
    } catch (err) {
      console.error('Failed to fetch stats:', err);
    }
  };

  // Fetch available roles
  const fetchRoles = async () => {
    try {
      const response = await fetch('/api/v1/admin/roles');
      if (!response.ok) throw new Error('Failed to fetch roles');

      const data = await response.json();
      setAvailableRoles(data.roles || []);
    } catch (err) {
      console.error('Failed to fetch roles:', err);
    }
  };

  useEffect(() => {
    fetchUsers();
    fetchStats();
    fetchRoles();
  }, [page, rowsPerPage, searchQuery, statusFilter]);

  // Show toast notification
  const showToast = (message, severity = 'success') => {
    setToast({ open: true, message, severity });
  };

  // Handle search
  const handleSearch = (event) => {
    setSearchQuery(event.target.value);
    setPage(0); // Reset to first page
  };

  // Handle pagination
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Open create user modal
  const handleCreateUser = () => {
    setIsEditMode(false);
    setFormData({
      email: '',
      username: '',
      firstName: '',
      lastName: '',
      password: '',
      enabled: true,
      emailVerified: false,
    });
    setCreateEditModalOpen(true);
  };

  // Open edit user modal
  const handleEditUser = (user) => {
    setIsEditMode(true);
    setCurrentUser(user);
    setFormData({
      email: user.email || '',
      username: user.username || '',
      firstName: user.firstName || '',
      lastName: user.lastName || '',
      password: '', // Don't show existing password
      enabled: user.enabled !== false,
      emailVerified: user.emailVerified || false,
    });
    setCreateEditModalOpen(true);
  };

  // Save user (create or update)
  const handleSaveUser = async () => {
    try {
      const url = isEditMode
        ? `/api/v1/admin/users/${currentUser.id}`
        : '/api/v1/admin/users';

      const method = isEditMode ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to save user');
      }

      showToast(isEditMode ? 'User updated successfully' : 'User created successfully');
      setCreateEditModalOpen(false);
      fetchUsers();
      fetchStats();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  // Delete user
  const handleDeleteUser = async () => {
    try {
      const response = await fetch(`/api/v1/admin/users/${currentUser.id}`, {
        method: 'DELETE',
      });

      if (!response.ok) throw new Error('Failed to delete user');

      showToast('User deleted successfully');
      setDeleteConfirmOpen(false);
      setCurrentUser(null);
      fetchUsers();
      fetchStats();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  // Reset password
  const handleResetPassword = async () => {
    try {
      const response = await fetch(`/api/v1/admin/users/${currentUser.id}/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ temporary: true }),
      });

      if (!response.ok) throw new Error('Failed to reset password');

      const data = await response.json();
      showToast(`Password reset. Temporary password: ${data.temporaryPassword || 'sent to email'}`);
      setResetPasswordOpen(false);
      setCurrentUser(null);
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  // Manage roles
  const handleManageRoles = async (user) => {
    setCurrentUser(user);
    setRoleModalOpen(true);

    try {
      const response = await fetch(`/api/v1/admin/users/${user.id}/roles`);
      if (!response.ok) throw new Error('Failed to fetch user roles');

      const data = await response.json();
      setUserRoles(data.roles || []);
    } catch (err) {
      showToast('Failed to load user roles', 'error');
    }
  };

  // Add role to user
  const handleAddRole = async (role) => {
    try {
      const response = await fetch(`/api/v1/admin/users/${currentUser.id}/roles`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role }),
      });

      if (!response.ok) throw new Error('Failed to add role');

      setUserRoles([...userRoles, role]);
      showToast('Role added successfully');
      fetchUsers(); // Refresh user list to show updated roles
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  // Remove role from user
  const handleRemoveRole = async (role) => {
    try {
      const response = await fetch(`/api/v1/admin/users/${currentUser.id}/roles/${role}`, {
        method: 'DELETE',
      });

      if (!response.ok) throw new Error('Failed to remove role');

      setUserRoles(userRoles.filter(r => r !== role));
      showToast('Role removed successfully');
      fetchUsers(); // Refresh user list to show updated roles
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  // View sessions
  const handleViewSessions = async (user) => {
    setCurrentUser(user);
    setSessionModalOpen(true);

    try {
      const response = await fetch(`/api/v1/admin/users/${user.id}/sessions`);
      if (!response.ok) throw new Error('Failed to fetch sessions');

      const data = await response.json();
      setUserSessions(data.sessions || []);
    } catch (err) {
      showToast('Failed to load sessions', 'error');
      setUserSessions([]);
    }
  };

  // Logout user (all sessions)
  const handleLogoutUser = async () => {
    try {
      const response = await fetch(`/api/v1/admin/users/${currentUser.id}/logout`, {
        method: 'POST',
      });

      if (!response.ok) throw new Error('Failed to logout user');

      showToast('User logged out successfully');
      setSessionModalOpen(false);
      setCurrentUser(null);
      setUserSessions([]);
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  // Get user initials for avatar
  const getUserInitials = (user) => {
    const first = user.firstName?.[0] || '';
    const last = user.lastName?.[0] || '';
    return (first + last).toUpperCase() || user.username?.[0]?.toUpperCase() || '?';
  };

  // Get status chip color
  const getStatusColor = (enabled) => {
    return enabled ? 'success' : 'error';
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Statistics Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ bgcolor: 'primary.main', color: 'white' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h4" fontWeight="bold">
                    {stats.totalUsers}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    Total Users
                  </Typography>
                </Box>
                <PeopleIcon sx={{ fontSize: 48, opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ bgcolor: 'success.main', color: 'white' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h4" fontWeight="bold">
                    {stats.activeUsers}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    Active Users
                  </Typography>
                </Box>
                <PersonAddIcon sx={{ fontSize: 48, opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ bgcolor: 'info.main', color: 'white' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h4" fontWeight="bold">
                    {stats.verifiedEmails}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    Verified Emails
                  </Typography>
                </Box>
                <VerifiedUserIcon sx={{ fontSize: 48, opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ bgcolor: 'warning.main', color: 'white' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="h4" fontWeight="bold">
                    {stats.adminUsers}
                  </Typography>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    Admin Users
                  </Typography>
                </Box>
                <AdminIcon sx={{ fontSize: 48, opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Main Content */}
      <Paper sx={{ p: 3 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h5" fontWeight="bold">
            User Management
          </Typography>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={handleCreateUser}
            sx={{
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              '&:hover': {
                background: 'linear-gradient(135deg, #764ba2 0%, #667eea 100%)',
              },
            }}
          >
            Create User
          </Button>
        </Box>

        {/* Filters */}
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              placeholder="Search by name, email, or username"
              value={searchQuery}
              onChange={handleSearch}
              InputProps={{
                startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} />,
              }}
            />
          </Grid>
          <Grid item xs={12} md={3}>
            <FormControl fullWidth>
              <InputLabel>Status Filter</InputLabel>
              <Select
                value={statusFilter}
                label="Status Filter"
                onChange={(e) => {
                  setStatusFilter(e.target.value);
                  setPage(0);
                }}
              >
                <MenuItem value="all">All Users</MenuItem>
                <MenuItem value="enabled">Enabled Only</MenuItem>
                <MenuItem value="disabled">Disabled Only</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={3}>
            <Button
              fullWidth
              variant="outlined"
              startIcon={<RefreshIcon />}
              onClick={() => {
                fetchUsers();
                fetchStats();
              }}
              sx={{ height: '56px' }}
            >
              Refresh
            </Button>
          </Grid>
        </Grid>

        {/* User Table */}
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
            <CircularProgress />
          </Box>
        ) : error ? (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        ) : (
          <>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Avatar</TableCell>
                    <TableCell>Name</TableCell>
                    <TableCell>Email</TableCell>
                    <TableCell>Username</TableCell>
                    <TableCell>Roles</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id} hover>
                      <TableCell>
                        <Avatar sx={{ bgcolor: 'primary.main' }}>
                          {getUserInitials(user)}
                        </Avatar>
                      </TableCell>
                      <TableCell>
                        {user.firstName} {user.lastName}
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          {user.email}
                          {user.emailVerified && (
                            <Tooltip title="Email Verified">
                              <VerifiedUserIcon color="success" fontSize="small" />
                            </Tooltip>
                          )}
                        </Box>
                      </TableCell>
                      <TableCell>{user.username}</TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                          {user.roles?.map((role) => (
                            <Chip
                              key={role}
                              label={role}
                              size="small"
                              color={role.includes('admin') ? 'error' : 'default'}
                            />
                          ))}
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={user.enabled ? 'Enabled' : 'Disabled'}
                          color={getStatusColor(user.enabled)}
                          size="small"
                        />
                      </TableCell>
                      <TableCell align="right">
                        <Tooltip title="Edit">
                          <IconButton
                            size="small"
                            onClick={() => handleEditUser(user)}
                            color="primary"
                          >
                            <EditIcon />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Manage Roles">
                          <IconButton
                            size="small"
                            onClick={() => handleManageRoles(user)}
                            color="info"
                          >
                            <SecurityIcon />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Reset Password">
                          <IconButton
                            size="small"
                            onClick={() => {
                              setCurrentUser(user);
                              setResetPasswordOpen(true);
                            }}
                            color="warning"
                          >
                            <VpnKeyIcon />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="View Sessions">
                          <IconButton
                            size="small"
                            onClick={() => handleViewSessions(user)}
                            color="success"
                          >
                            <LogoutIcon />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete">
                          <IconButton
                            size="small"
                            onClick={() => {
                              setCurrentUser(user);
                              setDeleteConfirmOpen(true);
                            }}
                            color="error"
                          >
                            <DeleteIcon />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>

            <TablePagination
              component="div"
              count={totalUsers}
              page={page}
              onPageChange={handleChangePage}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={handleChangeRowsPerPage}
              rowsPerPageOptions={[5, 10, 25, 50]}
            />
          </>
        )}
      </Paper>

      {/* Create/Edit User Modal */}
      <Dialog
        open={createEditModalOpen}
        onClose={() => setCreateEditModalOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          {isEditMode ? 'Edit User' : 'Create New User'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2 }}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="First Name"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Last Name"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Username"
                  required
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                />
              </Grid>
              {!isEditMode && (
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Password"
                    type="password"
                    required
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                </Grid>
              )}
              <Grid item xs={12} sm={6}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={formData.enabled}
                      onChange={(e) => setFormData({ ...formData, enabled: e.target.checked })}
                    />
                  }
                  label="Enabled"
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={formData.emailVerified}
                      onChange={(e) => setFormData({ ...formData, emailVerified: e.target.checked })}
                    />
                  }
                  label="Email Verified"
                />
              </Grid>
            </Grid>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCreateEditModalOpen(false)}>
            Cancel
          </Button>
          <Button
            variant="contained"
            onClick={handleSaveUser}
            disabled={!formData.email || !formData.username || (!isEditMode && !formData.password)}
          >
            {isEditMode ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Role Management Modal */}
      <Dialog
        open={roleModalOpen}
        onClose={() => setRoleModalOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          Manage Roles - {currentUser?.username}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 2 }}>
              Available Roles
            </Typography>
            <List>
              {availableRoles.map((role) => {
                const hasRole = userRoles.includes(role);
                return (
                  <ListItem
                    key={role}
                    secondaryAction={
                      <Button
                        size="small"
                        variant={hasRole ? 'outlined' : 'contained'}
                        color={hasRole ? 'error' : 'primary'}
                        onClick={() => hasRole ? handleRemoveRole(role) : handleAddRole(role)}
                      >
                        {hasRole ? 'Remove' : 'Add'}
                      </Button>
                    }
                  >
                    <Checkbox
                      checked={hasRole}
                      disabled
                    />
                    <ListItemText
                      primary={role}
                      secondary={hasRole ? 'Currently assigned' : 'Not assigned'}
                    />
                  </ListItem>
                );
              })}
            </List>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRoleModalOpen(false)}>
            Close
          </Button>
        </DialogActions>
      </Dialog>

      {/* Session Management Modal */}
      <Dialog
        open={sessionModalOpen}
        onClose={() => setSessionModalOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          Active Sessions - {currentUser?.username}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2 }}>
            {userSessions.length === 0 ? (
              <Alert severity="info">No active sessions</Alert>
            ) : (
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>IP Address</TableCell>
                      <TableCell>Started</TableCell>
                      <TableCell>Last Activity</TableCell>
                      <TableCell>Client</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {userSessions.map((session, index) => (
                      <TableRow key={index}>
                        <TableCell>{session.ipAddress || 'Unknown'}</TableCell>
                        <TableCell>
                          {session.started ? new Date(session.started).toLocaleString() : 'Unknown'}
                        </TableCell>
                        <TableCell>
                          {session.lastActivity ? new Date(session.lastActivity).toLocaleString() : 'Unknown'}
                        </TableCell>
                        <TableCell>{session.client || 'Unknown'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSessionModalOpen(false)}>
            Close
          </Button>
          {userSessions.length > 0 && (
            <Button
              variant="contained"
              color="error"
              startIcon={<LogoutIcon />}
              onClick={handleLogoutUser}
            >
              Logout All Sessions
            </Button>
          )}
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Modal */}
      <Dialog
        open={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete user <strong>{currentUser?.username}</strong>?
            This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteConfirmOpen(false)}>
            Cancel
          </Button>
          <Button
            variant="contained"
            color="error"
            onClick={handleDeleteUser}
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Reset Password Confirmation Modal */}
      <Dialog
        open={resetPasswordOpen}
        onClose={() => setResetPasswordOpen(false)}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle>Reset Password</DialogTitle>
        <DialogContent>
          <Typography>
            Reset password for user <strong>{currentUser?.username}</strong>?
            A temporary password will be generated and sent to their email.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setResetPasswordOpen(false)}>
            Cancel
          </Button>
          <Button
            variant="contained"
            color="warning"
            onClick={handleResetPassword}
          >
            Reset Password
          </Button>
        </DialogActions>
      </Dialog>

      {/* Toast Notification */}
      <Snackbar
        open={toast.open}
        autoHideDuration={6000}
        onClose={() => setToast({ ...toast, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          onClose={() => setToast({ ...toast, open: false })}
          severity={toast.severity}
          sx={{ width: '100%' }}
        >
          {toast.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default UserManagement;
