import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from '../contexts/ThemeContext';
import {
  ShieldCheckIcon,
  ArrowPathIcon,
  UserGroupIcon,
  KeyIcon,
  LockClosedIcon,
  LockOpenIcon,
  EyeIcon,
  EyeSlashIcon,
  TrashIcon,
  PlusIcon,
  PencilIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  InformationCircleIcon,
  ClockIcon,
  ComputerDesktopIcon,
  DevicePhoneMobileIcon,
  GlobeAltIcon,
  UserIcon,
  CogIcon,
  BellIcon,
  DocumentTextIcon,
  FireIcon,
  ShieldExclamationIcon,
  ServerIcon,
  CommandLineIcon,
  CheckIcon,
  XMarkIcon
} from '@heroicons/react/24/outline';

// Animation variants
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
      delayChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { y: 10, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 10
    }
  }
};

// Password strength calculator
const calculatePasswordStrength = (password) => {
  let strength = 0;
  if (!password) return { score: 0, label: 'None', color: 'gray' };

  if (password.length >= 8) strength += 20;
  if (password.length >= 12) strength += 20;
  if (/[a-z]/.test(password)) strength += 15;
  if (/[A-Z]/.test(password)) strength += 15;
  if (/[0-9]/.test(password)) strength += 15;
  if (/[^a-zA-Z0-9]/.test(password)) strength += 15;

  if (strength < 40) return { score: strength, label: 'Weak', color: 'red' };
  if (strength < 70) return { score: strength, label: 'Medium', color: 'yellow' };
  return { score: strength, label: 'Strong', color: 'green' };
};

// Password Strength Meter Component
const PasswordStrengthMeter = ({ password }) => {
  const strength = calculatePasswordStrength(password);

  return (
    <div className="mt-2">
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-gray-500 dark:text-gray-400">Password Strength</span>
        <span className={`text-xs font-medium ${
          strength.color === 'green' ? 'text-green-600 dark:text-green-400' :
          strength.color === 'yellow' ? 'text-yellow-600 dark:text-yellow-400' :
          'text-red-600 dark:text-red-400'
        }`}>
          {strength.label}
        </span>
      </div>
      <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${strength.score}%` }}
          className={`h-full ${
            strength.color === 'green' ? 'bg-green-500' :
            strength.color === 'yellow' ? 'bg-yellow-500' :
            'bg-red-500'
          }`}
        />
      </div>
    </div>
  );
};

export default function Security() {
  const { theme } = useTheme();
  const [activeTab, setActiveTab] = useState('system');
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  // System Security State
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showSshKeyModal, setShowSshKeyModal] = useState(false);
  const [sshKeys, setSshKeys] = useState([]);
  const [firewallStatus, setFirewallStatus] = useState(null);
  const [auditLogs, setAuditLogs] = useState([]);
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [newSshKey, setNewSshKey] = useState({ name: '', key: '' });

  // Application Security State (existing functionality)
  const [users, setUsers] = useState([]);
  const [apiKeys, setApiKeys] = useState([]);
  const [sessions, setSessions] = useState([]);

  useEffect(() => {
    if (activeTab === 'system') {
      loadSystemSecurity();
    } else if (activeTab === 'users') {
      loadUsers();
    } else if (activeTab === 'apikeys') {
      loadApiKeys();
    } else if (activeTab === 'sessions') {
      loadSessions();
    }
  }, [activeTab]);

  // System Security Functions
  const loadSystemSecurity = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadSshKeys(),
        loadFirewallStatus(),
        loadAuditLogs()
      ]);
    } catch (err) {
      setError('Failed to load system security information');
    } finally {
      setLoading(false);
    }
  };

  const loadSshKeys = async () => {
    try {
      const response = await fetch('/api/v1/system/security/ssh-keys');
      if (response.ok) {
        const data = await response.json();
        setSshKeys(data.keys || []);
      }
    } catch (err) {
      console.error('Failed to load SSH keys:', err);
    }
  };

  const loadFirewallStatus = async () => {
    try {
      const response = await fetch('/api/v1/system/security/firewall');
      if (response.ok) {
        const data = await response.json();
        setFirewallStatus(data);
      }
    } catch (err) {
      console.error('Failed to load firewall status:', err);
    }
  };

  const loadAuditLogs = async () => {
    try {
      const response = await fetch('/api/v1/system/security/audit-log?limit=50');
      if (response.ok) {
        const data = await response.json();
        setAuditLogs(data.logs || []);
      }
    } catch (err) {
      console.error('Failed to load audit logs:', err);
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();

    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      setError('New passwords do not match');
      return;
    }

    const strength = calculatePasswordStrength(passwordForm.newPassword);
    if (strength.score < 40) {
      setError('Password is too weak. Please use a stronger password.');
      return;
    }

    try {
      const response = await fetch('/api/v1/system/user/password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          current_password: passwordForm.currentPassword,
          new_password: passwordForm.newPassword
        })
      });

      if (response.ok) {
        setSuccess('Password changed successfully');
        setShowPasswordModal(false);
        setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
      } else {
        const data = await response.json();
        setError(data.detail || 'Failed to change password');
      }
    } catch (err) {
      setError('Failed to change password');
    }
  };

  const handleAddSshKey = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('/api/v1/system/security/ssh-keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSshKey)
      });

      if (response.ok) {
        setSuccess('SSH key added successfully');
        setShowSshKeyModal(false);
        setNewSshKey({ name: '', key: '' });
        loadSshKeys();
      } else {
        const data = await response.json();
        setError(data.detail || 'Failed to add SSH key');
      }
    } catch (err) {
      setError('Failed to add SSH key');
    }
  };

  const handleDeleteSshKey = async (keyId) => {
    if (!confirm('Are you sure you want to delete this SSH key?')) return;

    try {
      const response = await fetch(`/api/v1/system/security/ssh-keys/${keyId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        setSuccess('SSH key deleted successfully');
        loadSshKeys();
      } else {
        const data = await response.json();
        setError(data.detail || 'Failed to delete SSH key');
      }
    } catch (err) {
      setError('Failed to delete SSH key');
    }
  };

  const handleToggleFirewall = async (enabled) => {
    try {
      const response = await fetch('/api/v1/system/security/firewall', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled })
      });

      if (response.ok) {
        setSuccess(`Firewall ${enabled ? 'enabled' : 'disabled'} successfully`);
        loadFirewallStatus();
      } else {
        const data = await response.json();
        setError(data.detail || 'Failed to update firewall');
      }
    } catch (err) {
      setError('Failed to update firewall');
    }
  };

  // Application Security Functions (existing)
  const loadUsers = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/v1/users');
      if (response.ok) {
        const data = await response.json();
        setUsers(data.users || []);
      }
    } catch (err) {
      setError('Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  const loadApiKeys = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/v1/api-keys');
      if (response.ok) {
        const data = await response.json();
        setApiKeys(data.api_keys || []);
      }
    } catch (err) {
      setError('Failed to load API keys');
    } finally {
      setLoading(false);
    }
  };

  const loadSessions = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/v1/sessions');
      if (response.ok) {
        const data = await response.json();
        setSessions(data.sessions || []);
      }
    } catch (err) {
      setError('Failed to load sessions');
    } finally {
      setLoading(false);
    }
  };

  const refreshData = async () => {
    setRefreshing(true);
    if (activeTab === 'system') {
      await loadSystemSecurity();
    } else if (activeTab === 'users') {
      await loadUsers();
    } else if (activeTab === 'apikeys') {
      await loadApiKeys();
    } else if (activeTab === 'sessions') {
      await loadSessions();
    }
    setRefreshing(false);
  };

  const formatTimestamp = (timestamp) => {
    return new Date(timestamp).toLocaleString();
  };

  const getAuditEventIcon = (eventType) => {
    switch (eventType) {
      case 'login':
        return <UserIcon className="h-5 w-5 text-green-500" />;
      case 'logout':
        return <UserIcon className="h-5 w-5 text-gray-500" />;
      case 'password_change':
        return <KeyIcon className="h-5 w-5 text-blue-500" />;
      case 'ssh_key_added':
      case 'ssh_key_removed':
        return <CommandLineIcon className="h-5 w-5 text-purple-500" />;
      case 'firewall_change':
        return <FireIcon className="h-5 w-5 text-orange-500" />;
      case 'failed_login':
        return <ShieldExclamationIcon className="h-5 w-5 text-red-500" />;
      default:
        return <InformationCircleIcon className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6 p-6"
    >
      {/* Header */}
      <motion.div variants={itemVariants} className="flex items-center justify-between">
        <div>
          <h1 className={`text-4xl font-bold ${theme.text.primary} tracking-tight flex items-center gap-3`}>
            <ShieldCheckIcon className="h-10 w-10 text-green-500" />
            Security Center
          </h1>
          <p className={`${theme.text.secondary} mt-2`}>
            System & Application Security Management
          </p>
        </div>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={refreshData}
          disabled={refreshing}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
        >
          <ArrowPathIcon className={`h-5 w-5 ${refreshing ? 'animate-spin' : ''}`} />
          {refreshing ? 'Refreshing...' : 'Refresh'}
        </motion.button>
      </motion.div>

      {/* Error/Success Messages */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`
              p-4 rounded-2xl
              bg-gradient-to-r from-red-500/10 to-rose-500/10
              border border-red-500/20 backdrop-blur-xl
            `}
          >
            <div className="flex items-center gap-2">
              <ExclamationTriangleIcon className="h-5 w-5 text-red-500" />
              <p className="text-red-600 dark:text-red-400">{error}</p>
              <button
                onClick={() => setError(null)}
                className="ml-auto text-red-600 hover:text-red-800"
              >
                <XMarkIcon className="h-5 w-5" />
              </button>
            </div>
          </motion.div>
        )}

        {success && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`
              p-4 rounded-2xl
              bg-gradient-to-r from-green-500/10 to-emerald-500/10
              border border-green-500/20 backdrop-blur-xl
            `}
          >
            <div className="flex items-center gap-2">
              <CheckCircleIcon className="h-5 w-5 text-green-500" />
              <p className="text-green-600 dark:text-green-400">{success}</p>
              <button
                onClick={() => setSuccess(null)}
                className="ml-auto text-green-600 hover:text-green-800"
              >
                <XMarkIcon className="h-5 w-5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Tab Navigation */}
      <motion.div
        variants={itemVariants}
        className={`
          p-2 rounded-2xl
          bg-gradient-to-br from-gray-800/40 to-gray-900/40
          border border-gray-700/50 backdrop-blur-xl
        `}
      >
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('system')}
            className={`
              flex-1 py-3 px-4 rounded-xl font-medium text-sm transition-all
              ${activeTab === 'system'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg'
                : `${theme.text.secondary} hover:bg-gray-700/50`
              }
            `}
          >
            <div className="flex items-center justify-center gap-2">
              <ServerIcon className="h-5 w-5" />
              System Security
            </div>
          </button>

          <button
            onClick={() => setActiveTab('users')}
            className={`
              flex-1 py-3 px-4 rounded-xl font-medium text-sm transition-all
              ${activeTab === 'users'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg'
                : `${theme.text.secondary} hover:bg-gray-700/50`
              }
            `}
          >
            <div className="flex items-center justify-center gap-2">
              <UserGroupIcon className="h-5 w-5" />
              Users
            </div>
          </button>

          <button
            onClick={() => setActiveTab('apikeys')}
            className={`
              flex-1 py-3 px-4 rounded-xl font-medium text-sm transition-all
              ${activeTab === 'apikeys'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg'
                : `${theme.text.secondary} hover:bg-gray-700/50`
              }
            `}
          >
            <div className="flex items-center justify-center gap-2">
              <KeyIcon className="h-5 w-5" />
              API Keys
            </div>
          </button>

          <button
            onClick={() => setActiveTab('sessions')}
            className={`
              flex-1 py-3 px-4 rounded-xl font-medium text-sm transition-all
              ${activeTab === 'sessions'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg'
                : `${theme.text.secondary} hover:bg-gray-700/50`
              }
            `}
          >
            <div className="flex items-center justify-center gap-2">
              <ComputerDesktopIcon className="h-5 w-5" />
              Sessions
            </div>
          </button>
        </div>
      </motion.div>

      {/* Tab Content */}
      {activeTab === 'system' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Linux User Password Section */}
          <motion.div
            variants={itemVariants}
            className={`
              p-6 rounded-2xl
              bg-gradient-to-br from-gray-800/40 to-gray-900/40
              border border-gray-700/50 backdrop-blur-xl
            `}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <LockClosedIcon className="h-6 w-6 text-blue-500" />
                <h2 className={`text-xl font-bold ${theme.text.primary}`}>
                  User Password
                </h2>
              </div>
            </div>

            <p className={`${theme.text.secondary} mb-6 text-sm`}>
              Change the Linux system user password for SSH and terminal access
            </p>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setShowPasswordModal(true)}
              className="w-full px-4 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-xl hover:from-blue-700 hover:to-cyan-700 transition-all shadow-lg"
            >
              Change Password
            </motion.button>
          </motion.div>

          {/* SSH Keys Section */}
          <motion.div
            variants={itemVariants}
            className={`
              p-6 rounded-2xl
              bg-gradient-to-br from-gray-800/40 to-gray-900/40
              border border-gray-700/50 backdrop-blur-xl
            `}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <CommandLineIcon className="h-6 w-6 text-purple-500" />
                <h2 className={`text-xl font-bold ${theme.text.primary}`}>
                  SSH Keys
                </h2>
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowSshKeyModal(true)}
                className="px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm flex items-center gap-2"
              >
                <PlusIcon className="h-4 w-4" />
                Add Key
              </motion.button>
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto">
              {sshKeys.length === 0 ? (
                <p className={`${theme.text.secondary} text-sm text-center py-8`}>
                  No SSH keys configured
                </p>
              ) : (
                sshKeys.map((key) => (
                  <div
                    key={key.id}
                    className="p-3 rounded-lg bg-gray-800/50 backdrop-blur-sm flex items-center justify-between"
                  >
                    <div className="flex-1 min-w-0">
                      <div className={`text-sm font-medium ${theme.text.primary}`}>
                        {key.name}
                      </div>
                      <div className={`text-xs ${theme.text.secondary} font-mono truncate`}>
                        {key.fingerprint}
                      </div>
                    </div>
                    <button
                      onClick={() => handleDeleteSshKey(key.id)}
                      className="text-red-500 hover:text-red-400 ml-2"
                    >
                      <TrashIcon className="h-4 w-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </motion.div>

          {/* Firewall Status Section */}
          <motion.div
            variants={itemVariants}
            className={`
              p-6 rounded-2xl
              bg-gradient-to-br from-gray-800/40 to-gray-900/40
              border border-gray-700/50 backdrop-blur-xl
            `}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <FireIcon className="h-6 w-6 text-orange-500" />
                <h2 className={`text-xl font-bold ${theme.text.primary}`}>
                  Firewall
                </h2>
              </div>
              {firewallStatus && (
                <div className={`
                  px-3 py-1 rounded-full text-xs font-medium
                  ${firewallStatus.enabled
                    ? 'bg-green-500/20 text-green-400'
                    : 'bg-red-500/20 text-red-400'
                  }
                `}>
                  {firewallStatus.enabled ? 'Active' : 'Inactive'}
                </div>
              )}
            </div>

            {firewallStatus && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className={theme.text.secondary}>Status</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={firewallStatus.enabled}
                      onChange={(e) => handleToggleFirewall(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-800 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>

                <div>
                  <div className={`text-sm font-medium ${theme.text.primary} mb-2`}>
                    Active Rules ({firewallStatus.rules?.length || 0})
                  </div>
                  <div className="space-y-1 max-h-32 overflow-y-auto">
                    {firewallStatus.rules?.map((rule, idx) => (
                      <div
                        key={idx}
                        className="p-2 rounded bg-gray-800/50 text-xs font-mono text-gray-400"
                      >
                        {rule.port} - {rule.protocol} ({rule.action})
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </motion.div>

          {/* Security Audit Log Section */}
          <motion.div
            variants={itemVariants}
            className={`
              p-6 rounded-2xl
              bg-gradient-to-br from-gray-800/40 to-gray-900/40
              border border-gray-700/50 backdrop-blur-xl
              lg:col-span-1
            `}
          >
            <div className="flex items-center gap-3 mb-6">
              <DocumentTextIcon className="h-6 w-6 text-cyan-500" />
              <h2 className={`text-xl font-bold ${theme.text.primary}`}>
                Security Audit Log
              </h2>
            </div>

            <div className="space-y-2 max-h-96 overflow-y-auto">
              {auditLogs.length === 0 ? (
                <p className={`${theme.text.secondary} text-sm text-center py-8`}>
                  No audit logs available
                </p>
              ) : (
                auditLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3 rounded-lg bg-gray-800/50 backdrop-blur-sm"
                  >
                    <div className="flex items-start gap-3">
                      {getAuditEventIcon(log.event_type)}
                      <div className="flex-1 min-w-0">
                        <div className={`text-sm font-medium ${theme.text.primary}`}>
                          {log.event_type.replace(/_/g, ' ').toUpperCase()}
                        </div>
                        <div className={`text-xs ${theme.text.secondary} mt-1`}>
                          {log.description}
                        </div>
                        <div className={`text-xs ${theme.text.secondary} mt-1 opacity-60`}>
                          {formatTimestamp(log.timestamp)} • {log.user}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </motion.div>
        </div>
      )}

      {activeTab === 'users' && (
        <motion.div
          variants={itemVariants}
          className={`
            p-6 rounded-2xl
            bg-gradient-to-br from-gray-800/40 to-gray-900/40
            border border-gray-700/50 backdrop-blur-xl
          `}
        >
          <p className={`${theme.text.secondary} text-center py-12`}>
            User management features coming soon...
          </p>
        </motion.div>
      )}

      {activeTab === 'apikeys' && (
        <motion.div
          variants={itemVariants}
          className={`
            p-6 rounded-2xl
            bg-gradient-to-br from-gray-800/40 to-gray-900/40
            border border-gray-700/50 backdrop-blur-xl
          `}
        >
          <p className={`${theme.text.secondary} text-center py-12`}>
            API key management features coming soon...
          </p>
        </motion.div>
      )}

      {activeTab === 'sessions' && (
        <motion.div
          variants={itemVariants}
          className={`
            p-6 rounded-2xl
            bg-gradient-to-br from-gray-800/40 to-gray-900/40
            border border-gray-700/50 backdrop-blur-xl
          `}
        >
          <p className={`${theme.text.secondary} text-center py-12`}>
            Session management features coming soon...
          </p>
        </motion.div>
      )}

      {/* Change Password Modal */}
      <AnimatePresence>
        {showPasswordModal && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className={`
                max-w-md w-full p-6 rounded-2xl
                bg-gradient-to-br from-gray-800 to-gray-900
                border border-gray-700 shadow-2xl
              `}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className={`text-2xl font-bold ${theme.text.primary}`}>
                  Change Password
                </h2>
                <button
                  onClick={() => setShowPasswordModal(false)}
                  className="text-gray-400 hover:text-white"
                >
                  <XMarkIcon className="h-6 w-6" />
                </button>
              </div>

              <form onSubmit={handleChangePassword} className="space-y-4">
                <div>
                  <label className={`block text-sm font-medium ${theme.text.secondary} mb-2`}>
                    Current Password
                  </label>
                  <input
                    type="password"
                    value={passwordForm.currentPassword}
                    onChange={(e) => setPasswordForm({...passwordForm, currentPassword: e.target.value})}
                    required
                    className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-700 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium ${theme.text.secondary} mb-2`}>
                    New Password
                  </label>
                  <input
                    type="password"
                    value={passwordForm.newPassword}
                    onChange={(e) => setPasswordForm({...passwordForm, newPassword: e.target.value})}
                    required
                    minLength={8}
                    className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-700 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <PasswordStrengthMeter password={passwordForm.newPassword} />
                </div>

                <div>
                  <label className={`block text-sm font-medium ${theme.text.secondary} mb-2`}>
                    Confirm New Password
                  </label>
                  <input
                    type="password"
                    value={passwordForm.confirmPassword}
                    onChange={(e) => setPasswordForm({...passwordForm, confirmPassword: e.target.value})}
                    required
                    minLength={8}
                    className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-700 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowPasswordModal(false)}
                    className="px-4 py-2 text-gray-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all shadow-lg"
                  >
                    Change Password
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add SSH Key Modal */}
      <AnimatePresence>
        {showSshKeyModal && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className={`
                max-w-2xl w-full p-6 rounded-2xl
                bg-gradient-to-br from-gray-800 to-gray-900
                border border-gray-700 shadow-2xl
              `}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className={`text-2xl font-bold ${theme.text.primary}`}>
                  Add SSH Key
                </h2>
                <button
                  onClick={() => setShowSshKeyModal(false)}
                  className="text-gray-400 hover:text-white"
                >
                  <XMarkIcon className="h-6 w-6" />
                </button>
              </div>

              <form onSubmit={handleAddSshKey} className="space-y-4">
                <div>
                  <label className={`block text-sm font-medium ${theme.text.secondary} mb-2`}>
                    Key Name
                  </label>
                  <input
                    type="text"
                    value={newSshKey.name}
                    onChange={(e) => setNewSshKey({...newSshKey, name: e.target.value})}
                    placeholder="e.g., My Laptop"
                    required
                    className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-700 text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className={`block text-sm font-medium ${theme.text.secondary} mb-2`}>
                    Public Key
                  </label>
                  <textarea
                    value={newSshKey.key}
                    onChange={(e) => setNewSshKey({...newSshKey, key: e.target.value})}
                    placeholder="ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC..."
                    required
                    rows={6}
                    className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-700 text-white font-mono text-sm focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowSshKeyModal(false)}
                    className="px-4 py-2 text-gray-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all shadow-lg"
                  >
                    Add SSH Key
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
