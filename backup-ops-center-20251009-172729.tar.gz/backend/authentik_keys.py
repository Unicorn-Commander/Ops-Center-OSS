"""
Authentik User API Keys Integration
Stores encrypted API keys in Authentik user attributes
"""
import os
import httpx
from typing import Dict, List, Optional
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class AuthentikKeysManager:
    """Manages user API keys stored in Authentik user attributes"""

    def __init__(self):
        """Initialize Authentik API client"""
        self.authentik_url = os.getenv('AUTHENTIK_URL', 'http://authentik-server:9000')
        self.api_token = os.getenv('AUTHENTIK_API_TOKEN')

        if not self.api_token:
            logger.warning("AUTHENTIK_API_TOKEN not set, API key storage will be limited")

        self.base_url = f"{self.authentik_url}/api/v3"
        self.headers = {
            'Authorization': f'Bearer {self.api_token}',
            'Content-Type': 'application/json'
        }

    async def get_user_by_username(self, username: str) -> Optional[Dict]:
        """
        Get user details from Authentik by username

        Args:
            username: Username to lookup

        Returns:
            User object or None if not found
        """
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.base_url}/core/users/",
                    headers=self.headers,
                    params={'username': username}
                )
                response.raise_for_status()

                results = response.json().get('results', [])
                return results[0] if results else None
        except Exception as e:
            logger.error(f"Error fetching user {username}: {e}")
            return None

    async def save_user_api_key(
        self,
        username: str,
        provider: str,
        encrypted_key: str,
        key_name: Optional[str] = None
    ) -> bool:
        """
        Save encrypted API key to Authentik user attributes

        Args:
            username: User's username
            provider: API provider (openai, anthropic, etc.)
            encrypted_key: Encrypted API key
            key_name: Optional custom name for the key

        Returns:
            True if successful, False otherwise
        """
        try:
            # Get user
            user = await self.get_user_by_username(username)
            if not user:
                logger.error(f"User {username} not found")
                return False

            user_id = user['pk']
            attributes = user.get('attributes', {})

            # Initialize api_keys structure if not exists
            if 'byok_api_keys' not in attributes:
                attributes['byok_api_keys'] = {}

            # Save key with metadata
            attributes['byok_api_keys'][provider] = {
                'encrypted_key': encrypted_key,
                'name': key_name or provider,
                'created_at': datetime.utcnow().isoformat(),
                'updated_at': datetime.utcnow().isoformat()
            }

            # Update user attributes
            async with httpx.AsyncClient() as client:
                response = await client.patch(
                    f"{self.base_url}/core/users/{user_id}/",
                    headers=self.headers,
                    json={'attributes': attributes}
                )
                response.raise_for_status()

            logger.info(f"Saved API key for user {username}, provider {provider}")
            return True

        except Exception as e:
            logger.error(f"Error saving API key: {e}")
            return False

    async def get_user_api_keys(self, username: str) -> Dict[str, Dict]:
        """
        Get all API keys for a user

        Args:
            username: User's username

        Returns:
            Dictionary of provider -> key data
        """
        try:
            user = await self.get_user_by_username(username)
            if not user:
                logger.error(f"User {username} not found")
                return {}

            attributes = user.get('attributes', {})
            return attributes.get('byok_api_keys', {})

        except Exception as e:
            logger.error(f"Error getting API keys: {e}")
            return {}

    async def get_user_api_key(self, username: str, provider: str) -> Optional[str]:
        """
        Get a specific encrypted API key for a user

        Args:
            username: User's username
            provider: API provider

        Returns:
            Encrypted API key or None if not found
        """
        keys = await self.get_user_api_keys(username)
        key_data = keys.get(provider)
        return key_data.get('encrypted_key') if key_data else None

    async def delete_user_api_key(self, username: str, provider: str) -> bool:
        """
        Delete an API key for a user

        Args:
            username: User's username
            provider: API provider to delete

        Returns:
            True if successful, False otherwise
        """
        try:
            user = await self.get_user_by_username(username)
            if not user:
                logger.error(f"User {username} not found")
                return False

            user_id = user['pk']
            attributes = user.get('attributes', {})

            # Remove key if exists
            if 'byok_api_keys' in attributes and provider in attributes['byok_api_keys']:
                del attributes['byok_api_keys'][provider]

                # Update user attributes
                async with httpx.AsyncClient() as client:
                    response = await client.patch(
                        f"{self.base_url}/core/users/{user_id}/",
                        headers=self.headers,
                        json={'attributes': attributes}
                    )
                    response.raise_for_status()

                logger.info(f"Deleted API key for user {username}, provider {provider}")
                return True
            else:
                logger.warning(f"No API key found for user {username}, provider {provider}")
                return False

        except Exception as e:
            logger.error(f"Error deleting API key: {e}")
            return False

    async def update_user_api_key(
        self,
        username: str,
        provider: str,
        encrypted_key: Optional[str] = None,
        key_name: Optional[str] = None
    ) -> bool:
        """
        Update an existing API key

        Args:
            username: User's username
            provider: API provider
            encrypted_key: New encrypted key (optional, keeps old if None)
            key_name: New name (optional, keeps old if None)

        Returns:
            True if successful, False otherwise
        """
        try:
            user = await self.get_user_by_username(username)
            if not user:
                logger.error(f"User {username} not found")
                return False

            user_id = user['pk']
            attributes = user.get('attributes', {})

            # Check if key exists
            if 'byok_api_keys' not in attributes or provider not in attributes['byok_api_keys']:
                logger.error(f"No existing key found for user {username}, provider {provider}")
                return False

            # Update key data
            key_data = attributes['byok_api_keys'][provider]
            if encrypted_key:
                key_data['encrypted_key'] = encrypted_key
            if key_name:
                key_data['name'] = key_name
            key_data['updated_at'] = datetime.utcnow().isoformat()

            # Update user attributes
            async with httpx.AsyncClient() as client:
                response = await client.patch(
                    f"{self.base_url}/core/users/{user_id}/",
                    headers=self.headers,
                    json={'attributes': attributes}
                )
                response.raise_for_status()

            logger.info(f"Updated API key for user {username}, provider {provider}")
            return True

        except Exception as e:
            logger.error(f"Error updating API key: {e}")
            return False


# Singleton instance
_authentik_instance: Optional[AuthentikKeysManager] = None


def get_authentik_manager() -> AuthentikKeysManager:
    """Get or create singleton Authentik manager instance"""
    global _authentik_instance
    if _authentik_instance is None:
        _authentik_instance = AuthentikKeysManager()
    return _authentik_instance
