"""
Authentik SSO Integration for Ops Center
Provides user management through Authentik API
"""

import httpx
import os
from typing import Dict, List, Optional, Any
from pydantic import BaseModel
from datetime import datetime

class AuthentikUser(BaseModel):
    """User model from Authentik"""
    pk: str
    username: str
    email: str
    name: str
    is_active: bool
    is_superuser: bool = False
    groups: List[str] = []
    last_login: Optional[datetime] = None
    date_joined: Optional[datetime] = None

class AuthentikUserCreate(BaseModel):
    """Create user request"""
    username: str
    email: str
    name: str
    password: str
    is_active: bool = True
    groups: List[str] = []

class AuthentikUserUpdate(BaseModel):
    """Update user request"""
    email: Optional[str] = None
    name: Optional[str] = None
    is_active: Optional[bool] = None
    groups: Optional[List[str]] = None

class AuthentikPasswordReset(BaseModel):
    """Password reset request"""
    password: str

class AuthentikGroup(BaseModel):
    """Group model from Authentik"""
    pk: str
    name: str
    is_superuser: bool = False
    users: List[str] = []

class AuthentikIntegration:
    """Manages integration with Authentik SSO"""
    
    def __init__(self):
        # Get Authentik connection details from environment
        self.base_url = os.getenv("AUTHENTIK_URL", "http://authentik-server:9000")
        self.token = os.getenv("AUTHENTIK_BOOTSTRAP_TOKEN", "")
        
        # If internal URL doesn't work, try external
        if "authentik-server" in self.base_url:
            # Check if we can reach internal URL
            try:
                with httpx.Client() as client:
                    response = client.get(f"{self.base_url}/api/v3/root/config/", timeout=2)
                    if response.status_code != 200:
                        # Fall back to external URL
                        self.base_url = "http://192.168.1.135:9005"
            except:
                self.base_url = "http://192.168.1.135:9005"
        
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
    
    async def get_users(self) -> List[AuthentikUser]:
        """Get all users from Authentik"""
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/api/v3/core/users/",
                    headers=self.headers
                )
                if response.status_code == 200:
                    data = response.json()
                    users = []
                    for user_data in data.get("results", []):
                        # Get user's groups
                        groups = [g["name"] for g in user_data.get("groups_obj", [])]
                        
                        users.append(AuthentikUser(
                            pk=str(user_data["pk"]),
                            username=user_data["username"],
                            email=user_data.get("email", ""),
                            name=user_data.get("name", ""),
                            is_active=user_data.get("is_active", False),
                            is_superuser=user_data.get("is_superuser", False),
                            groups=groups,
                            last_login=user_data.get("last_login"),
                            date_joined=user_data.get("date_joined")
                        ))
                    return users
                return []
            except Exception as e:
                print(f"Error fetching users from Authentik: {e}")
                return []
    
    async def create_user(self, user: AuthentikUserCreate) -> Optional[AuthentikUser]:
        """Create a new user in Authentik"""
        async with httpx.AsyncClient() as client:
            try:
                # Create user
                user_data = {
                    "username": user.username,
                    "email": user.email,
                    "name": user.name,
                    "is_active": user.is_active,
                    "groups": user.groups,
                    "path": "users"
                }
                
                response = await client.post(
                    f"{self.base_url}/api/v3/core/users/",
                    headers=self.headers,
                    json=user_data
                )
                
                if response.status_code in [200, 201]:
                    created_user = response.json()
                    
                    # Set password
                    if user.password:
                        await self.set_user_password(created_user["pk"], user.password)
                    
                    return AuthentikUser(
                        pk=str(created_user["pk"]),
                        username=created_user["username"],
                        email=created_user.get("email", ""),
                        name=created_user.get("name", ""),
                        is_active=created_user.get("is_active", False),
                        groups=user.groups
                    )
                else:
                    print(f"Error creating user: {response.text}")
                    return None
            except Exception as e:
                print(f"Error creating user in Authentik: {e}")
                return None
    
    async def update_user(self, user_id: str, update: AuthentikUserUpdate) -> Optional[AuthentikUser]:
        """Update a user in Authentik"""
        async with httpx.AsyncClient() as client:
            try:
                update_data = {}
                if update.email is not None:
                    update_data["email"] = update.email
                if update.name is not None:
                    update_data["name"] = update.name
                if update.is_active is not None:
                    update_data["is_active"] = update.is_active
                if update.groups is not None:
                    update_data["groups"] = update.groups
                
                response = await client.patch(
                    f"{self.base_url}/api/v3/core/users/{user_id}/",
                    headers=self.headers,
                    json=update_data
                )
                
                if response.status_code == 200:
                    updated_user = response.json()
                    return AuthentikUser(
                        pk=str(updated_user["pk"]),
                        username=updated_user["username"],
                        email=updated_user.get("email", ""),
                        name=updated_user.get("name", ""),
                        is_active=updated_user.get("is_active", False),
                        groups=[g["name"] for g in updated_user.get("groups_obj", [])]
                    )
                return None
            except Exception as e:
                print(f"Error updating user in Authentik: {e}")
                return None
    
    async def delete_user(self, user_id: str) -> bool:
        """Delete a user from Authentik"""
        async with httpx.AsyncClient() as client:
            try:
                response = await client.delete(
                    f"{self.base_url}/api/v3/core/users/{user_id}/",
                    headers=self.headers
                )
                return response.status_code in [204, 200]
            except Exception as e:
                print(f"Error deleting user from Authentik: {e}")
                return False
    
    async def set_user_password(self, user_id: str, password: str) -> bool:
        """Set a user's password in Authentik"""
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    f"{self.base_url}/api/v3/core/users/{user_id}/set_password/",
                    headers=self.headers,
                    json={"password": password}
                )
                return response.status_code in [204, 200]
            except Exception as e:
                print(f"Error setting user password in Authentik: {e}")
                return False
    
    async def get_groups(self) -> List[AuthentikGroup]:
        """Get all groups from Authentik"""
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.base_url}/api/v3/core/groups/",
                    headers=self.headers
                )
                if response.status_code == 200:
                    data = response.json()
                    groups = []
                    for group_data in data.get("results", []):
                        groups.append(AuthentikGroup(
                            pk=str(group_data["pk"]),
                            name=group_data["name"],
                            is_superuser=group_data.get("is_superuser", False),
                            users=[str(u) for u in group_data.get("users", [])]
                        ))
                    return groups
                return []
            except Exception as e:
                print(f"Error fetching groups from Authentik: {e}")
                return []
    
    async def create_group(self, name: str, is_superuser: bool = False) -> Optional[AuthentikGroup]:
        """Create a new group in Authentik"""
        async with httpx.AsyncClient() as client:
            try:
                group_data = {
                    "name": name,
                    "is_superuser": is_superuser
                }
                
                response = await client.post(
                    f"{self.base_url}/api/v3/core/groups/",
                    headers=self.headers,
                    json=group_data
                )
                
                if response.status_code in [200, 201]:
                    created_group = response.json()
                    return AuthentikGroup(
                        pk=str(created_group["pk"]),
                        name=created_group["name"],
                        is_superuser=created_group.get("is_superuser", False)
                    )
                return None
            except Exception as e:
                print(f"Error creating group in Authentik: {e}")
                return None
    
    async def add_user_to_group(self, user_id: str, group_id: str) -> bool:
        """Add a user to a group in Authentik"""
        async with httpx.AsyncClient() as client:
            try:
                # Get current user data
                user_response = await client.get(
                    f"{self.base_url}/api/v3/core/users/{user_id}/",
                    headers=self.headers
                )
                
                if user_response.status_code == 200:
                    user_data = user_response.json()
                    current_groups = user_data.get("groups", [])
                    
                    # Add new group if not already present
                    if group_id not in current_groups:
                        current_groups.append(group_id)
                        
                        # Update user with new groups
                        update_response = await client.patch(
                            f"{self.base_url}/api/v3/core/users/{user_id}/",
                            headers=self.headers,
                            json={"groups": current_groups}
                        )
                        return update_response.status_code == 200
                    return True  # Already in group
                return False
            except Exception as e:
                print(f"Error adding user to group in Authentik: {e}")
                return False
    
    async def get_user_stats(self) -> Dict[str, Any]:
        """Get user statistics from Authentik"""
        users = await self.get_users()
        groups = await self.get_groups()
        
        active_users = [u for u in users if u.is_active]
        admin_users = [u for u in users if u.is_superuser or "authentik Admins" in u.groups]
        
        return {
            "total_users": len(users),
            "active_users": len(active_users),
            "admin_users": len(admin_users),
            "total_groups": len(groups),
            "recent_signups": len([u for u in users if u.date_joined and 
                                  (datetime.now() - u.date_joined).days < 7])
        }

# Create singleton instance
authentik_integration = AuthentikIntegration()