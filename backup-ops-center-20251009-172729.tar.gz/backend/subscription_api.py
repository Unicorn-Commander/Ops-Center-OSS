"""
Subscription Management API Endpoints
"""

from fastapi import APIRouter, HTTPException, Depends, Request
from typing import List, Dict, Optional
from pydantic import BaseModel
import httpx

from subscription_manager import (
    subscription_manager,
    SubscriptionPlan,
    ServiceAccessConfig,
    ServiceType,
    PermissionLevel
)

router = APIRouter(prefix="/api/v1/subscriptions", tags=["subscriptions"])

# Request/Response models
class PlanCreateRequest(BaseModel):
    plan: SubscriptionPlan

class PlanUpdateRequest(BaseModel):
    updates: Dict

class UserAccessResponse(BaseModel):
    services: List[ServiceAccessConfig]
    plan: Optional[SubscriptionPlan]
    usage: Dict

# Helper function to get current user
async def get_current_user(request: Request):
    """Get current user from session"""
    session_token = request.cookies.get("session_token")
    if not session_token:
        raise HTTPException(status_code=401, detail="Not authenticated")

    # Import sessions from server.py
    # In production, you'd import this properly
    # For now, we'll call the /api/v1/auth/me endpoint
    async with httpx.AsyncClient() as client:
        response = await client.get(
            "http://localhost:8000/api/v1/auth/me",
            cookies={"session_token": session_token}
        )
        if response.status_code != 200:
            raise HTTPException(status_code=401, detail="Invalid session")

        return response.json()

async def require_admin(request: Request):
    """Require admin role"""
    user = await get_current_user(request)
    if not user.get("is_admin") and user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user

# Public endpoints (anyone can view plans)
@router.get("/plans")
async def get_plans():
    """Get all active subscription plans"""
    plans = subscription_manager.get_all_plans()
    return {"plans": [plan.dict() for plan in plans]}

@router.get("/plans/{plan_id}")
async def get_plan(plan_id: str):
    """Get specific plan details"""
    plan = subscription_manager.get_plan(plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    return plan.dict()

# User endpoints (authenticated users)
@router.get("/my-access")
async def get_my_access(request: Request):
    """Get services accessible to current user"""
    user = await get_current_user(request)

    # Get user's plan and role
    user_plan = user.get("subscription_tier", "trial")
    user_role = user.get("role", "user")

    # Get accessible services
    services = subscription_manager.get_user_accessible_services(user_plan, user_role)

    # Get plan details
    plan = subscription_manager.get_plan(user_plan)

    # TODO: Get usage from Lago
    usage = {
        "api_calls_used": 0,
        "api_calls_limit": plan.api_calls_limit if plan else 0,
        "period_start": None,
        "period_end": None
    }

    return {
        "services": [svc.dict() for svc in services],
        "plan": plan.dict() if plan else None,
        "usage": usage,
        "user": {
            "role": user_role,
            "subscription_tier": user_plan,
            "is_admin": user.get("is_admin", False)
        }
    }

@router.post("/check-access/{service}")
async def check_service_access(service: ServiceType, request: Request):
    """Check if user has access to specific service"""
    user = await get_current_user(request)

    user_plan = user.get("subscription_tier", "trial")
    user_role = user.get("role", "user")

    has_access = subscription_manager.check_service_access(service, user_plan, user_role)

    if not has_access:
        # Get upgrade URL
        plan = subscription_manager.get_plan(user_plan)
        return {
            "has_access": False,
            "current_plan": user_plan,
            "upgrade_required": True,
            "upgrade_url": "/billing/upgrade",
            "message": f"This service requires a higher subscription tier"
        }

    return {
        "has_access": True,
        "current_plan": user_plan
    }

# Admin endpoints (admin only)
@router.post("/plans", dependencies=[Depends(require_admin)])
async def create_plan(plan_request: PlanCreateRequest, request: Request):
    """Create new subscription plan (admin only)"""
    try:
        plan = subscription_manager.create_plan(plan_request.plan)
        return {"success": True, "plan": plan.dict()}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.put("/plans/{plan_id}", dependencies=[Depends(require_admin)])
async def update_plan(plan_id: str, update_request: PlanUpdateRequest, request: Request):
    """Update subscription plan (admin only)"""
    plan = subscription_manager.update_plan(plan_id, update_request.updates)
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    return {"success": True, "plan": plan.dict()}

@router.delete("/plans/{plan_id}", dependencies=[Depends(require_admin)])
async def delete_plan(plan_id: str, request: Request):
    """Delete (deactivate) subscription plan (admin only)"""
    success = subscription_manager.delete_plan(plan_id)
    if not success:
        raise HTTPException(status_code=404, detail="Plan not found")
    return {"success": True, "message": f"Plan {plan_id} deactivated"}

@router.get("/services")
async def get_all_services():
    """Get all available services (for admin reference)"""
    return {"services": [svc.dict() for svc in subscription_manager.service_access]}

@router.get("/admin/user-access/{user_id}", dependencies=[Depends(require_admin)])
async def get_user_access_admin(user_id: str, request: Request):
    """Get service access for specific user (admin only)"""
    # TODO: Fetch user details from Authentik
    # For now, return example
    return {
        "user_id": user_id,
        "message": "User access lookup - to be implemented with Authentik integration"
    }
