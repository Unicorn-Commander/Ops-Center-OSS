# Quick Setup Guide: Authentik Groups for Ops Center Roles

## Overview

This guide shows how to configure Authentik groups to assign roles to ops-center users.

## Step-by-Step Setup

### 1. Access Authentik Admin Panel

Navigate to: `https://auth.unicorncommander.ai/if/admin/`

Login with:
- Username: `akadmin`
- Password: `CmonWidja2626`

### 2. Create Groups

1. Click **Directory** in the left sidebar
2. Click **Groups**
3. Click **Create** button

Create the following groups:

#### Admin Group
- **Name**: `admins`
- **Parent**: (none)
- **Attributes**: (optional)
  ```json
  {
    "description": "Full system administrators",
    "ops_center_role": "admin"
  }
  ```

#### Power Users Group
- **Name**: `power_users`
- **Parent**: (none)
- **Attributes**: (optional)
  ```json
  {
    "description": "Advanced users with configuration access",
    "ops_center_role": "power_user"
  }
  ```

#### Users Group
- **Name**: `users`
- **Parent**: (none)
- **Attributes**: (optional)
  ```json
  {
    "description": "Standard users",
    "ops_center_role": "user"
  }
  ```

#### Viewers Group
- **Name**: `viewers`
- **Parent**: (none)
- **Attributes**: (optional)
  ```json
  {
    "description": "Read-only access",
    "ops_center_role": "viewer"
  }
  ```

### 3. Assign Users to Groups

1. Click **Directory** > **Users**
2. Select a user
3. Click the **Groups** tab
4. Click **Add to existing group**
5. Select the appropriate group(s)
6. Click **Add**

**Note**: Users can be in multiple groups. They will receive the highest priority role.

### 4. Configure OAuth Application

Ensure the ops-center OAuth application includes groups in the token:

1. Click **Applications** > **Providers**
2. Find **ops-center** provider
3. Click **Edit**
4. Under **Advanced protocol settings**:
   - Ensure **Include claims in id_token** is checked
   - Add `groups` to the **Scopes** if not present
5. Save changes

### 5. Test Role Assignment

1. Logout of ops-center if logged in
2. Login with a test user
3. Check backend logs for role assignment:
   ```bash
   docker logs unicorn-ops-center 2>&1 | grep "mapped to role"
   ```

Expected output:
```
INFO: User 'testuser' mapped to role 'power_user' via group/role 'power_users'
```

## Quick Reference: Role Capabilities

### Admin
- Full system access
- User management
- Service deployment
- Security configuration
- All power_user capabilities

### Power User
- Advanced configurations
- Docker service management
- Network settings
- Extension management
- All user capabilities

### User
- Basic operations
- File uploads
- View logs
- Dashboard access
- All viewer capabilities

### Viewer
- View system status
- Read logs
- Read-only dashboard
- No modifications allowed

## Troubleshooting

### User Gets 'viewer' Role Despite Being in Admin Group

**Check**:
1. Verify group name is exactly `admins` (case-insensitive)
2. Check user is actually a member of the group
3. User needs to logout and login again after group changes
4. Check backend logs for group detection

**Debug**:
```bash
# Check what groups are being sent
docker logs unicorn-ops-center 2>&1 | grep "User groups/roles found"
```

### Groups Not Appearing in Token

**Fix**:
1. Go to **Applications** > **Providers**
2. Edit the **ops-center** provider
3. Ensure **Scopes** includes `openid`, `profile`, `email`, and `groups`
4. Check **Include claims in id_token** is enabled
5. Save and retry

### User Cannot Access Admin Features

**Verify**:
1. User role is actually 'admin':
   ```bash
   docker logs unicorn-ops-center 2>&1 | grep "assigned role: admin"
   ```
2. Backend is using the updated code with role_mapper
3. Session is fresh (logout/login after group changes)

## Alternative: Using Authentik Roles

Instead of groups, you can use Authentik roles:

1. Click **Directory** > **Roles**
2. Create roles named: `admin`, `power_user`, `user`, `viewer`
3. Assign roles to users
4. Ensure roles are included in the OAuth token

## Migration from Old System

If upgrading from the old system where all users were admins:

1. **Before applying changes**: Export list of current users
2. **After applying changes**: All users will be 'viewer' by default
3. **Assign proper roles**: Add users to appropriate groups
4. **Inform users**: They need to logout and login again

## Security Best Practices

1. **Principle of Least Privilege**: Start users with 'viewer' or 'user' role
2. **Regular Audits**: Review group memberships quarterly
3. **Admin Group**: Keep admin group small (2-3 trusted users)
4. **Power Users**: Use for technical staff who need advanced access
5. **Documentation**: Document why each user has their assigned role

## API Access

To check a user's role programmatically:

```bash
# Get current user info (requires valid session cookie)
curl -X GET https://unicorncommander.ai/api/auth/user \
  -H "Cookie: session_token=YOUR_SESSION_TOKEN" \
  -H "Content-Type: application/json"
```

Response:
```json
{
  "username": "john.doe",
  "email": "john.doe@example.com",
  "role": "power_user",
  "groups": ["power_users", "users"]
}
```

## Resources

- **Authentik Groups Documentation**: https://goauthentik.io/docs/user-group-role/group
- **Authentik OAuth Provider**: https://goauthentik.io/docs/providers/oauth2
- **Role Mapping Details**: See ROLE_MAPPING.md in this directory

## Support

For assistance:
- Check logs: `docker logs unicorn-ops-center`
- Test role mapper: `python3 role_mapper.py`
- Email: aaron@magicunicorn.tech
